package com.example.meshchat.ble

import android.bluetooth.*
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.os.ParcelUuid
import android.util.Log
import java.util.UUID

/** Base BLE GATT advertising/server. Full peer discovery, client connections and message relay are not yet implemented. */
class BleMeshManager(private val context: Context) {
    private val adapter: BluetoothAdapter? = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val serviceUuid = UUID.fromString("0000ffff-0000-1000-8000-00805f9b34fb")
    private val characteristicUuid = UUID.fromString("0000feee-0000-1000-8000-00805f9b34fb")
    private var server: BluetoothGattServer? = null
    private var advertising = false

    fun startAdvertising() {
        val advertiser = adapter?.bluetoothLeAdvertiser ?: run { Log.w(TAG, "BLE advertiser unavailable"); return }
        val settings = AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY).setConnectable(true).setTimeout(0).setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM).build()
        val data = AdvertiseData.Builder().addServiceUuid(ParcelUuid(serviceUuid)).setIncludeDeviceName(false).build()
        try { advertiser.startAdvertising(settings, data, callback) } catch (e: SecurityException) { Log.e(TAG, "Bluetooth permission missing", e) }
    }
    fun startGattServer() {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            server = manager.openGattServer(context, gattCallback)
            val service = BluetoothGattService(serviceUuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            val characteristic = BluetoothGattCharacteristic(characteristicUuid, BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_WRITE or BluetoothGattCharacteristic.PERMISSION_READ)
            service.addCharacteristic(characteristic)
            server?.addService(service)
        } catch (e: SecurityException) { Log.e(TAG, "Bluetooth permission missing", e) }
    }
    private val gattCallback = object : BluetoothGattServerCallback() {
        override fun onCharacteristicWriteRequest(device: BluetoothDevice?, requestId: Int, characteristic: BluetoothGattCharacteristic?, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?) {
            if (characteristic?.uuid == characteristicUuid && value != null) Log.i(TAG, "Received ${value.size} bytes from a peer")
            if (responseNeeded && device != null) try { server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null) } catch (e: SecurityException) { Log.e(TAG, "Cannot respond to GATT write", e) }
        }
    }
    private val callback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) { advertising = true; Log.i(TAG, "BLE advertising started") }
        override fun onStartFailure(errorCode: Int) { advertising = false; Log.e(TAG, "BLE advertising failed: $errorCode") }
    }
    fun stop() {
        try { if (advertising) adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback) } catch (e: SecurityException) { Log.w(TAG, "Cannot stop advertising", e) }
        try { server?.close() } catch (e: SecurityException) { Log.w(TAG, "Cannot close GATT server", e) }
        advertising = false; server = null
    }
    companion object { private const val TAG = "MeshChatBLE" }
}
