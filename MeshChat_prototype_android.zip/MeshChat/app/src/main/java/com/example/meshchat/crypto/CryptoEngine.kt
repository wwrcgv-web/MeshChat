package com.example.meshchat.crypto

import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Cryptographic building blocks only. Key exchange, identity persistence and protocol framing must be designed before production use. */
object CryptoEngine {
    fun newSigningKeyPair(): KeyPair = KeyPairGenerator.getInstance("Ed25519").generateKeyPair()
    fun sign(data: ByteArray, keyPair: KeyPair): ByteArray = Signature.getInstance("Ed25519").run { initSign(keyPair.private); update(data); sign() }
    fun verify(data: ByteArray, signature: ByteArray, publicKey: java.security.PublicKey): Boolean = Signature.getInstance("Ed25519").run { initVerify(publicKey); update(data); verify(signature) }
    fun newAesKey(): SecretKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
    data class Encrypted(val nonce: ByteArray, val ciphertext: ByteArray)
    fun encrypt(plain: ByteArray, key: SecretKey): Encrypted {
        val nonce = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        return Encrypted(nonce, cipher.doFinal(plain))
    }
    fun decrypt(encrypted: Encrypted, key: SecretKey): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, encrypted.nonce))
        return cipher.doFinal(encrypted.ciphertext)
    }
}
