# MeshChat — prototype Android Kotlin / Jetpack Compose

Ce projet est un **point de départ**, pas encore une messagerie mesh complète ni une APK prête pour le Play Store.

## Contenu
- Interface Compose sombre « terminal vert ».
- Demande des permissions Bluetooth à l'utilisateur.
- Service de premier plan avec notification.
- Base d'annonce BLE et serveur GATT.
- Fonctions de base Ed25519 et AES-256-GCM.

## Limitations importantes
- Le scan des appareils, le client GATT, la connexion automatique, le transport des messages, le relais avec déduplication et l'échange sûr des clés ne sont pas terminés.
- Le texte saisi dans l'interface reste local et n'est pas envoyé à un autre téléphone.
- Wi-Fi Aware n'est pas implémenté et n'est pas disponible sur tous les appareils Android.
- Avant publication, ajouter des tests sur plusieurs téléphones, la gestion des connexions/pertes de connexion, les limites de taille BLE, la rotation/persistance des clés, le protocole de paquets et les exigences Google Play.

## Compilation
1. Sur un ordinateur, installer Android Studio récent et le JDK compatible.
2. Décompresser ce ZIP et ouvrir le dossier `MeshChat` dans Android Studio.
3. Laisser Gradle synchroniser, puis lancer l'application sur un téléphone Android physique.
4. Autoriser les permissions Bluetooth lorsque l'application le demande.

La compilation et le fonctionnement Bluetooth doivent être vérifiés dans Android Studio et sur des appareils réels. Ce ZIP ne contient pas d'APK compilée.
